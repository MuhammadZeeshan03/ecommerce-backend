## Running the project

Clone the project and run

``` npm install```

This will install all the required dependencies.

To run the project run

```npm run dev``` 

Check that you have MySQL installed on your system. And create a database named "test". If you have any other database you can change the name of databse in ```database.js``` file.
